package ir.ariaai.app

import android.app.Application

class AriaApplication : Application()
