package ir.ariaai.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object OnlineClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    // Ollama native endpoint: POST /api/chat
    suspend fun reply(baseUrl: String, prompt: String): String = withContext(Dispatchers.IO) {
        require(baseUrl.startsWith("http://") || baseUrl.startsWith("https://")) {
            "آدرس سرور باید با http:// یا https:// شروع شود."
        }
        val body = JSONObject().apply {
            put("model", "qwen2.5:3b")
            put("stream", false)
            put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        }.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(baseUrl.trimEnd('/') + "/api/chat")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("سرور پاسخ ${response.code} داد: $raw")
            JSONObject(raw).optJSONObject("message")?.optString("content")
                ?.takeIf { it.isNotBlank() } ?: "پاسخ خالی از سرور دریافت شد."
        }
    }
}
