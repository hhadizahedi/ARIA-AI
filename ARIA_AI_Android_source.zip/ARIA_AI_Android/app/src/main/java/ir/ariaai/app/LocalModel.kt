package ir.ariaai.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import java.io.File

/**
 * Offline engine. Put a MediaPipe-compatible .task model at:
 * /data/user/0/ir.ariaai.app/files/models/aria_model.task
 *
 * The model is not bundled because model files are large and have separate licenses.
 */
object LocalModel {
    private var engine: LlmInference? = null
    private const val MODEL_FILE = "aria_model.task"

    suspend fun installFromUri(context: Context, uri: Uri) = withContext(Dispatchers.IO) {
        val target = File(context.filesDir, "models/$MODEL_FILE")
        target.parentFile?.mkdirs()
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "فایل انتخاب‌شده قابل خواندن نیست." }
            target.outputStream().use { output -> input.copyTo(output) }
        }
        require(target.length() > 0L) { "فایل مدل خالی است." }
    }

    fun isModelAvailable(context: Context? = null): Boolean {
        if (context == null) return false
        return File(context.filesDir, "models/$MODEL_FILE").exists()
    }

    @Synchronized
    fun initialize(context: Context) {
        if (engine != null) return
        val model = File(context.filesDir, "models/$MODEL_FILE")
        check(model.exists()) {
            "مدل آفلاین نصب نشده است. فایل سازگار aria_model.task را در پوشه models قرار بده."
        }
        val options = LlmInferenceOptions.builder()
            .setModelPath(model.absolutePath)
            .setMaxTokens(1024)
            .build()
        engine = LlmInference.createFromOptions(context, options)
    }

    @Synchronized
    fun reply(prompt: String): String {
        val active = engine ?: error("موتور آفلاین هنوز راه‌اندازی نشده است.")
        return active.generateResponse(prompt)
    }
}
