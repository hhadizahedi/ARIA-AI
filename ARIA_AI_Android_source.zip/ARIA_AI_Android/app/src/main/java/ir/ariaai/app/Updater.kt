package ir.ariaai.app

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object Updater {
    // Replace this URL with the raw update.json URL in your own GitHub repository.
    private const val MANIFEST_URL =
        "https://raw.githubusercontent.com/hhadizahedi/ARIA-AI/main/ARIA_AI_Android/update.json"

    suspend fun checkAndOffer(activity: Activity) = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
            val request = Request.Builder().url(MANIFEST_URL).build()
            val manifestText = client.newCall(request).execute().use {
                if (!it.isSuccessful) error("دریافت اطلاعات نسخه ناموفق بود: ${it.code}")
                it.body?.string() ?: error("فایل نسخه خالی است")
            }
            val manifest = JSONObject(manifestText)
            val latestCode = manifest.optInt("versionCode", 1)
            val currentCode = BuildConfig.VERSION_CODE
            if (latestCode <= currentCode) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(activity, "برنامه به‌روز است.", Toast.LENGTH_LONG).show()
                }
                return@withContext
            }
            val apkUrl = manifest.getString("apkUrl")
            withContext(Dispatchers.Main) {
                android.app.AlertDialog.Builder(activity)
                    .setTitle("نسخه جدید ARIA AI")
                    .setMessage("نسخه ${manifest.optString("versionName")} آماده دریافت است. اکنون دانلود شود؟")
                    .setNegativeButton("بعداً", null)
                    .setPositiveButton("دانلود") { _, _ -> downloadAndInstall(activity, apkUrl) }
                    .show()
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                Toast.makeText(activity, "بررسی به‌روزرسانی ناموفق بود: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun downloadAndInstall(activity: Activity, url: String) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle("ARIA AI update")
                .setDescription("دریافت نسخه جدید")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalFilesDir(activity, Environment.DIRECTORY_DOWNLOADS, "aria-ai-update.apk")
            val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val id = manager.enqueue(request)
            Toast.makeText(activity, "دانلود شروع شد. پس از دانلود فایل را از اعلان‌ها باز کن.", Toast.LENGTH_LONG).show()
            // Android's DownloadManager notification opens the APK. Installation is always user-confirmed.
        } catch (e: Exception) {
            Toast.makeText(activity, "دانلود انجام نشد: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }
}
