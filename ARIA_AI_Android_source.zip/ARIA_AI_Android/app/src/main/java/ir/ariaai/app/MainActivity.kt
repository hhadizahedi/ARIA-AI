package ir.ariaai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.widget.Toast

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AriaTheme { AriaScreen() } }
    }
}

@Composable
fun AriaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF75A7FF),
            secondary = Color(0xFF8AB4F8),
            background = Color(0xFF101827),
            surface = Color(0xFF1A2638)
        ),
        content = content
    )
}

@Composable
fun AriaScreen(vm: ChatViewModel = viewModel()) {
    val messages by vm.messages.collectAsState()
    val busy by vm.busy.collectAsState()
    val mode by vm.mode.collectAsState()
    val serverUrl by vm.serverUrl.collectAsState()
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val activity = androidx.compose.ui.platform.LocalContext.current as ComponentActivity
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        LocalModel.installFromUri(activity.applicationContext, uri)
                        LocalModel.initialize(activity.applicationContext)
                    }
                    Toast.makeText(activity, "مدل آفلاین نصب و آماده شد.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(activity, "نصب مدل ناموفق بود: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBarCompat(
                mode = mode,
                onSettings = { showSettings = true },
                onClear = { vm.clearChat() }
            )
        },
        bottomBar = {
            Column(Modifier.fillMaxWidth().background(Color(0xFF101827)).padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("پیامت را بنویس...") },
                        maxLines = 4,
                        shape = RoundedCornerShape(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        enabled = input.isNotBlank() && !busy,
                        onClick = {
                            val prompt = input.trim()
                            input = ""
                            scope.launch { vm.send(prompt, activity.applicationContext) }
                        }
                    ) { Icon(Icons.Default.Send, contentDescription = "ارسال") }
                }
                Text(
                    "ARIA AI • نسخه ${BuildConfig.VERSION_NAME}",
                    color = Color.LightGray,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 5.dp)
                )
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp),
            reverseLayout = false,
            contentPadding = PaddingValues(vertical = 14.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(top = 48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFF75A7FF), modifier = Modifier.size(54.dp))
                        Text("سلام! من آریا هستم.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("دستیار هوشمند فارسی تو", color = Color.LightGray)
                        Spacer(Modifier.height(20.dp))
                        Text("برای شروع یک پیام بنویس.", color = Color.LightGray)
                    }
                }
            }
            items(messages) { message ->
                MessageBubble(message)
                Spacer(Modifier.height(10.dp))
            }
            if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        }
    }

    if (showSettings) {
        SettingsDialog(
            currentMode = mode,
            currentUrl = serverUrl,
            onDismiss = { showSettings = false },
            onSave = { newMode, url ->
                vm.setConnection(newMode, url)
                showSettings = false
            },
            onModelHelp = { modelPicker.launch(arrayOf("*/*")) },
            onUpdate = { vm.checkForUpdate(activity) }
        )
    }
}

@Composable
private fun TopAppBarCompat(mode: EngineMode, onSettings: () -> Unit, onClear: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF17243B)).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Psychology, null, tint = Color(0xFF75A7FF), modifier = Modifier.size(30.dp))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("ARIA AI", fontWeight = FontWeight.Bold, color = Color.White)
            Text(if (mode == EngineMode.LOCAL) "حالت مستقل" else "اتصال به کامپیوتر", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
        }
        IconButton(onClick = onClear) { Icon(Icons.Default.DeleteOutline, "پاک کردن گفتگو", tint = Color.White) }
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "تنظیمات", tint = Color.White) }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (isUser) Color(0xFF254A7A) else Color(0xFF1D2B40),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Text(message.content, Modifier.padding(13.dp), color = Color.White)
        }
    }
}

@Composable
fun SettingsDialog(
    currentMode: EngineMode,
    currentUrl: String,
    onDismiss: () -> Unit,
    onSave: (EngineMode, String) -> Unit,
    onModelHelp: () -> Unit,
    onUpdate: () -> Unit
) {
    var mode by remember { mutableStateOf(currentMode) }
    var url by remember { mutableStateOf(currentUrl) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تنظیمات ARIA AI") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("موتور هوش مصنوعی")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == EngineMode.LOCAL, { mode = EngineMode.LOCAL })
                    Text("مستقل روی گوشی")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == EngineMode.COMPUTER, { mode = EngineMode.COMPUTER })
                    Text("متصل به کامپیوتر")
                }
                OutlinedTextField(
                    value = url, onValueChange = { url = it },
                    label = { Text("آدرس سرور (مثلاً http://192.168.1.10:11434)") },
                    singleLine = true
                )
                OutlinedButton(onClick = onModelHelp, modifier = Modifier.fillMaxWidth()) {
                    Text("بررسی فایل مدل آفلاین")
                }
                OutlinedButton(onClick = onUpdate, modifier = Modifier.fillMaxWidth()) {
                    Text("بررسی به‌روزرسانی برنامه")
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(mode, url.trim()) }) { Text("ذخیره") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}


