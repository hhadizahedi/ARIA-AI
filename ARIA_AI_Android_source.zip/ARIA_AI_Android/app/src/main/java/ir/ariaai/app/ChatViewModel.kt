package ir.ariaai.app

import android.app.Activity
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class EngineMode { LOCAL, COMPUTER }

data class ChatMessage(val role: String, val content: String)

class ChatViewModel : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = _messages.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()
    private val _mode = MutableStateFlow(EngineMode.COMPUTER)
    val mode = _mode.asStateFlow()
    private val _serverUrl = MutableStateFlow("http://192.168.1.10:11434")
    val serverUrl = _serverUrl.asStateFlow()

    fun setConnection(newMode: EngineMode, url: String) {
        _mode.value = newMode
        if (url.isNotBlank()) _serverUrl.value = url.trimEnd('/')
    }

    fun clearChat() { _messages.value = emptyList() }

    suspend fun send(prompt: String, context: android.content.Context? = null) {
        _messages.value = _messages.value + ChatMessage("user", prompt)
        _busy.value = true
        try {
            val answer = if (_mode.value == EngineMode.LOCAL) {
                val ctx = context ?: error("زمینه اجرای مدل در دسترس نیست.")
                withContext(Dispatchers.IO) {
                    LocalModel.initialize(ctx)
                    LocalModel.reply(prompt)
                }
            } else {
                OnlineClient.reply(_serverUrl.value, prompt)
            }
            _messages.value = _messages.value + ChatMessage("assistant", answer)
        } catch (e: Exception) {
            _messages.value = _messages.value + ChatMessage(
                "assistant",
                "خطا در ارتباط یا اجرای مدل: ${e.localizedMessage ?: "خطای نامشخص"}\nتنظیمات موتور و اتصال را بررسی کن."
            )
        } finally { _busy.value = false }
    }

    fun checkLocalModel(context: android.content.Context? = null) {
        if (context == null || !LocalModel.isModelAvailable(context)) return
        runCatching { LocalModel.initialize(context) }
    }

    fun checkForUpdate(activity: Activity) {
        viewModelScope.launch { Updater.checkAndOffer(activity) }
    }
}
